//
//  TresEspiasDemaisApp.swift
//  TresEspiasDemais
//
//  Created by User on 12/09/23.
//

import SwiftUI

@main
struct TresEspiasDemaisApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
